﻿using UnityEngine;
using System.Collections;

public enum Tiles
{
    Unset,
    Grass,
    Water,
    Brick,
    Sandstone
}
